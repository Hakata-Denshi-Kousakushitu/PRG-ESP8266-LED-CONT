The hardware is released under Creative Commons Share-alike 3.0.

All other code is open source so please feel free to do anything you want with it; you buy me a beer if you use this and we meet someday (Beerware license).